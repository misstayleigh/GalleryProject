# library-jekyll-theme

Easily create a digital bookshelf of your favorite books.

[Demo](http://alexcarpenter.github.io/library-jekyll-theme/)

## Author
- [Website](http://alexcarpenter.me)
- [Twitter](https://twitter.com/hybrid_alex)
- [Github](https://github.com/alexcarpenter)

## License
[MIT](https://github.com/alexcarpenter/library-jekyll-theme/blob/master/LICENSE)
